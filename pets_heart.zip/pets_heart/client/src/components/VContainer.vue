<template>
  <div class="v-container">
    <slot />
  </div>
</template>

<style>
.v-container {
  width: 100%;
}
</style>
