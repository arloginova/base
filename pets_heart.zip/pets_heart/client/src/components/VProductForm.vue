<script setup>
import { ref } from 'vue';
import axios from 'axios';

const props = defineProps({
  userId: {
    type: String,
    required: true,
  },
  companyId: {
    type: String,
    required: true,
  },
  onSubmit: {
    type: Function,
    required: true,
  },
});

const name = ref('');
const price = ref(0);
const weight = ref(0);
const description = ref('');
const image = ref(null);

const onFileChange = (event) => {
  image.value = event.target.files[0];
};

const submitForm = async () => {
  const formData = {
    name: name.value,
    price: price.value,
    weight: weight.value,
    description: description.value,
    userId: props.userId,
	companyId: props.companyId,
  };

  try {
    await axios.post('http://127.0.0.1:8080/addProduct', formData);
    props.onSubmit();
  } catch (error) {
    console.error('Ошибка при отправке формы:', error);
  }
};
</script>



<template>
  <div class="form">
    <div class="form-group">
      <label>Фотография</label>
      <input type="file" @change="onFileChange" accept="image/*" />
    </div>
    <div class="form-group">
      <label>Название</label>
      <input type="text" v-model="name" />
    </div>
    <div class="form-group">
      <div class="price-weight-container">
        <div class="small">
          <label>Цена</label>
          <input type="number" v-model="price" />
        </div>
        <div class="small">
          <label>Вес</label>
          <input type="number" v-model="weight" />
        </div>
      </div>
    </div>
    <div class="form-group">
      <label>Описание</label>
      <input type="text" v-model="description"></input>
    </div>
	<button @click="submitForm">Сохранить</button>
  </div>
</template>

<style scoped>
.form {
  flex: 1;
  margin: 0 auto;
  padding: 20px;
  border-radius: 5px;
}

h2 {
  margin-top: 0;
  margin-bottom: 20px;
  text-align: center;
}

.form-group {
  margin-bottom: 20px;
  width: 516px;
}

label {
  display: block;
  margin-bottom: 24px;
  font-weight: 400;
  font-size: 22px;
}

input[type="text"],
input[type="number"],
textarea {
  width: 100%;
  height: 62px;
  padding: 10px;
  border: 1px solid #e9e9eb;
  border-radius: 7px;
  box-sizing: border-box;
  font-size: 20px;
  font-weight: 300;
}

textarea {
  height: 120px;
}

.price-weight-container {
  display: flex;
  gap: 20px;
}

button {
  display: block;
  width: 413px;
  padding: 19px;
  background-color: black;
  color: white;
  border: none;
  font-size: 20px;
  border-radius: 7px;
  cursor: pointer;
}

.small {
  width: 140px;
}
</style>
