<template>
    <router-link 
        class="v-logo"
        to="/"
        
    />
    <img src="../assets/images/logo.svg" alt="" width="130" height="60">
</template>

<style>
</style>