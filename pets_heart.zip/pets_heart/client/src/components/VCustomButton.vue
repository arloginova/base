<script setup>
defineProps({
  buttonText: {
    type: String,
    default: "Кнопка",
  },
  isActive: {
    type: Boolean,
    default: false,
  },
});

const emit = defineEmits(["clicked"]);

function onClicked() {
  emit("clicked");
}
</script>

<template>
  <div class="container">
    <input
      type="button"
      :value="buttonText"
      :class="['custom-button', { active: isActive }]"
      @click="onClicked"
    />
  </div>
</template>

<style scoped>
.container {
  width: 326px;
  height: 62px;
}

.custom-button {
  width: 100%;
  background-color: white;
  color: black;
  border: 1.5px solid #e9e9eb;
  font-size: 16px;
  padding: 16px;
  cursor: pointer;
  border-radius: 7px;
}

.custom-button.active {
  background-color: #f5f5f5;
  border: 1.5px solid #f5f5f5;
}
</style>
