<script setup></script>

<template>
  <input type="text" class="cupon-input" placeholder="Код купона" />
</template>

<style scoped>
.cupon-input {
  margin-top: 45px;
  padding: 10px;
  border: 1px solid #9d0000;
  border-radius: 100px;
  outline: none;
  font-family: "Jost";
  font-size: 18px;
  font-weight: 300;
}
</style>
