<script setup>
import { ref } from "vue";
import axios from "axios";

const props = defineProps({
  userId: {
    type: Number,
    required: true,
  },
  onSubmit: {
    type: Function,
    required: true,
  },
});

const orgName = ref("");
const address = ref("");
const description = ref("");
const orgType = ref("");
const category = ref("");
const selectedFile = ref(null);

const onFileChange = (event) => {
  selectedFile.value = event.target.files[0];
};

const submitForm = async () => {
  const formData = {
    orgName: orgName.value,
    address: address.value,
    description: description.value,
    orgType: orgType.value,
    category: category.value,
    id: props.userId,
  };

  try {
    const response = await axios.post(
      "http://127.0.0.1:8080/addCompany",
      formData,
      {
        headers: {
          "Content-Type": "application/json",
        },
      }
    );
    console.log(response.data);
    props.onSubmit(response.data.info);
  } catch (error) {
    console.error(error);
  }
};
</script>

<template>
  <div class="form">
    <div class="form-group">
      <label>Фотография</label>
      <input type="file" @change="onFileChange" accept="image/*" />
    </div>
    <div class="form-group">
      <label>Название организации</label>
      <input type="text" v-model="orgName" />
    </div>
    <div class="form-group">
      <label>Адрес</label>
      <input type="text" v-model="address" />
    </div>
    <div class="form-group">
      <label>Описание</label>
      <input type="text" v-model="description" />
    </div>
    <div class="form-group">
      <label>Тип организации</label>
      <div class="org-type-container">
        <label>
          <input
            type="radio"
            value="Компания"
            v-model="orgType"
            name="orgType"
          />
          Компания
        </label>
        <label>
          <input
            type="radio"
            value="Частный специалист"
            v-model="orgType"
            name="orgType"
          />
          Частный специалист
        </label>
        <label>
          <input
            type="radio"
            value="Магазин"
            v-model="orgType"
            name="orgType"
          />
          Магазин
        </label>
      </div>
    </div>
    <div class="form-group">
      <label>Категории</label>
      <div class="categories-container">
        <div class="category-row">
          <label>
            <input
              type="radio"
              value="Обучение"
              v-model="category"
              name="category"
            />
            Обучение
          </label>
          <label>
            <input
              type="radio"
              value="Еда"
              v-model="category"
              name="category"
            />
            Еда
          </label>
          <label>
            <input
              type="radio"
              value="Дом"
              v-model="category"
              name="category"
            />
            Дом
          </label>
          <label>
            <input
              type="radio"
              value="Здоровье"
              v-model="category"
              name="category"
            />
            Здоровье
          </label>
        </div>
        <div class="category-row">
          <label>
            <input
              type="radio"
              value="Красота"
              v-model="category"
              name="category"
            />
            Красота
          </label>
          <label>
            <input
              type="radio"
              value="Зоо"
              v-model="category"
              name="category"
            />
            Зоо
          </label>
          <label>
            <input
              type="radio"
              value="Авто"
              v-model="category"
              name="category"
            />
            Авто
          </label>
          <label>
            <input
              type="radio"
              value="Праздник"
              v-model="category"
              name="category"
            />
            Праздник
          </label>
        </div>
      </div>
    </div>
    <button @click="submitForm">Сохранить</button>
  </div>
</template>

<style scoped>
.form {
  flex: 1;
  margin: 0 auto;
  padding: 20px;
  border-radius: 5px;
}

h2 {
  margin-top: 0;
  margin-bottom: 20px;
  text-align: center;
}

.form-group {
  margin-bottom: 20px;
}

label {
  display: block;
  margin-bottom: 24px;
  font-weight: 400;
  font-size: 22px;
}

input[type="text"],
textarea,
select {
  width: 516px;
  height: 62px;
  padding: 10px;
  border: 1px solid #e9e9eb;
  border-radius: 7px;
  box-sizing: border-box;
  font-size: 20px;
  font-weight: 300;
}

input[type="radio"],
input[type="checkbox"] {
  margin-right: 5px;
}

.org-type-container {
  display: flex;
  gap: 20px;
}

.categories-container {
  display: flex;
  flex-direction: column;
  gap: 10px;
}

.category-row {
  display: flex;
  gap: 20px;
}

button {
  display: block;
  width: 413px;
  padding: 19px;
  background-color: black;
  color: white;
  border: none;
  font-size: 20px;
  border-radius: 7px;
  cursor: pointer;
}
</style>
