<script setup>
import VRow from "@/components/UI/VRow.vue";
import axios from "axios";
import { ref } from "vue";
import { useRouter } from "vue-router";

const data = ref(null);
const loading = ref(false);
const error = ref(null);
const phone = ref("");

const router = useRouter();

async function fetchData() {
  try {
    loading.value = true;
    const response = await axios.post("http://127.0.0.1:8080/login", {
      phone: phone.value,
    });
    data.value = response.data;
    const id = data.value.id;
    console.log(data.value);
    router.push(`/profile/${id}`);
  } catch (err) {
    console.error(err);
    error.value = err.message;
  } finally {
    loading.value = false;
  }
}
</script>

<template>
  <VRow class="auth-container">
    <div class="container">
      <p class="header">
        Введите ваш номер телефона, чтобы войти/зарегистрироваться
      </p>
      <div class="input-container">
        <input
          type="text"
          class="phone-input"
          placeholder="+7 902 303 45 56"
          v-model="phone"
        />
      </div>
      <div class="button-container">
        <input
          type="button"
          value="Продолжить"
          class="auth-button"
          @click="fetchData"
        />
      </div>
    </div>
  </VRow>
</template>

<style scoped>
.auth-container {
  justify-content: center;
}

.header {
  font-size: 22px;
  font-weight: 300;
  margin-bottom: 20px;
}

.container {
  width: 475px;
  height: 331px;
  border: 2px solid #e9e9eb;
  padding: 49px 31px 43px 31px;
  text-align: center;
  border-radius: 20px;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: space-between;
}

.input-container {
  margin-bottom: 20px;
  width: 100%;
}

.phone-input {
  background-color: #e9e9eb;
  border: none;
  padding: 10px;
  height: 62px;
  width: 100%;
  border-radius: 5px;
  font-size: 20px;
  font-weight: 300;
  color: #615e5e;
}

.phone-input:focus {
  outline: none;
}

.phone-input::placeholder {
  color: #615e5e;
  font-weight: 300;
}

.button-container {
  width: 100%;
}

.auth-button {
  background-color: #000000;
  color: #fff;
  border: none;
  padding: 19px;
  width: 100%;
  border-radius: 7px;
  cursor: pointer;
  font-size: 20px;
}
</style>
