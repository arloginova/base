<template>
  <header class="v-header">
    <v-container>
      <v-row align="center">
        <img src="@/assets/images/ultra_logo.svg" alt="" class="logo" />
        <v-row v-if="showNav" class="nav-row">
          <p class="nav-text">Организации</p>
          <p class="nav-text">Настройки</p>
          <p class="nav-text">Сотрудники</p>
        </v-row>
      </v-row>
    </v-container>
  </header>
</template>

<script setup>
import { ref } from "vue";
import { useRouter } from "vue-router";
import { useAuth } from "@/composables";
import VRow from "@/components/UI/VRow.vue";
import VCol from "@/components/UI/VCol.vue";
import VLogo from "@/components/VLogo.vue";
import VSidebarMenu from "@/components/VSidebarMenu.vue";
import VContainer from "@/components/VContainer.vue";

defineProps({
  showNav: {
    type: Boolean,
    default: false,
  },
});
</script>

<style>
.logo {
  padding-right: 94px;
}

.route_button {
  text-decoration: none;
}

.v-header {
  background-size: cover;
  width: 100%;
}

.nav-text {
  font-size: 18px;
  font-weight: 400;
  cursor: pointer;
}

.nav-row {
  gap: 52px;
}
</style>
