<script setup>
import VRow from "@/components/UI/VRow.vue";
import VCol from "@/components/UI/VCol.vue";
import { ref } from "vue";
import { useRouter } from "vue-router";

const activeButton = ref("phone");
const router = useRouter();

function setActiveButton(button) {
  activeButton.value = button;
}

function goToProfile() {
  const userId = 123;
  router.push(`/profile/${userId}`);
}
</script>

<template>
  <VCol class="container">
    <VRow align="center">
      <img src="@/assets/images/logo.svg" alt="" class="logo-img" />
      <p class="logo-text">Pets's Heart</p>
    </VRow>

    <p class="info-header">Вход в личный кабинет</p>
    <p class="info-body">Создайте новый аккаунт или войдите в существующий</p>

    <VRow class="buttons-row">
      <button
        class="custom-button"
        :class="{ active: activeButton === 'phone' }"
        @click="setActiveButton('phone')"
      >
        Телефон
      </button>
      <button
        class="custom-button"
        :class="{ active: activeButton === 'email' }"
        @click="setActiveButton('email')"
      >
        Email
      </button>
    </VRow>

    <VRow class="input-container" v-if="activeButton === 'phone'">
      <img src="@/assets/images/russia.svg" alt="" />
      <p class="number-input">+7</p>
      <input type="text" class="custom-input" placeholder="Номер телефона" />
    </VRow>
    <VRow class="input-container" v-else>
      <input type="email" class="custom-input" placeholder="Введите почту" />
    </VRow>
    <p></p>
    <button class="login-button" @click="goToProfile">Далее</button>
  </VCol>
</template>

<style scoped>
.container {
  width: 450px;
  margin: 0 auto;
}

.logo-img {
  margin-right: 20px;
}

.logo-text {
  font-size: 40px;
  font-weight: 400;
}

.info-header {
  font-size: 20px;
  font-weight: 600;
  margin-bottom: 12px;
  margin-top: 36px;
}

.info-body {
  font-size: 16px;
  font-weight: 400;
  margin-bottom: 20px;
}

.custom-button {
  padding: 8px 16px;
  border: none;
  border-radius: 22px;
  font-weight: 500;
  font-size: 15px;
  background-color: transparent;
  cursor: pointer;
}

.custom-button.active {
  background-color: #d2f96a;
}

.buttons-row {
  margin-bottom: 12px;
}

.input-container {
  border-bottom: 1px solid #b592ff;
  padding-bottom: 5px;
  margin-bottom: 20px;
}

.number-input {
  color: #b592ff;
  font-size: 15px;
  margin: 0 7px;
}

.custom-input {
  border: none;
  font-size: 16px;
  color: #968f8f;
}

.custom-input:focus {
  outline: none;
}

.login-button {
  width: 100%;
  border: 3px solid black;
  background-color: transparent;
  padding: 12.5px 0;
  border-radius: 100px;
  font-size: 15px;
  cursor: pointer;
}
</style>
