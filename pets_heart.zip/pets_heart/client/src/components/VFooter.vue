<template>
  <footer class="v-footer">
    <v-container>
      <VRow>
        <div class="info-text">
          <p class="info-header">Помощь и поддержка</p>
          <p class="info-body">8 (800) 600-13-10</p>
        </div>
        <div class="info-text">
          <p class="info-header">Электронный адрес</p>
          <p class="info-body">team@ultra.io</p>
        </div>
      </VRow>
    </v-container>
  </footer>
</template>

<script setup>
import VContainer from "@/components/VContainer.vue";
import VRow from "./UI/VRow.vue";
</script>

<style>
.info-text {
  font-size: 18px;
  font-weight: 400;
  padding-right: 131px;
}

.info-header {
  color: #615e5e;
  font-size: 14px;
}
</style>
