import { createRouter, createWebHistory } from 'vue-router';
import { useAuth } from '@/composables';

const routes = [
    {
        name: 'Home',
        path: '/',
        component: () => import('@/pages/index.vue'),
        meta: {
            auth: false,
            title: 'Главная'
        }
    },
    {
        path: '/profile/:id',
        name: 'profile',
        component: () => import('@/pages/profile/profile.vue'),
        meta: {
            title: "Профиль",
        }
    },
    {
        name: 'Create company',
        path: '/companyCreate/:phone',
        component: () => import('@/pages/catalog/category.vue'),
        meta: {
            auth: false
        }
    },

];

export const router = createRouter({
    history: createWebHistory(),
    routes
});

const { isAuth } = useAuth();

router.beforeEach((to) => {
    const hasAuth = to.meta.auth;
    const title = to.meta.title;

    document.title = title || 'Наш магазин';

    if (hasAuth && !isAuth.value) {
        router.push('/auth/sign-in');

        return false;
    }
});