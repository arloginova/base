<template>
  <VCol>
    <VRow class="header" align="center" justify="beetwen">
      <VRow align="center">
        <div class="image-container">
          <img src="@/assets/images/logo.svg" alt="" class="image-logo" />
        </div>
        <p class="logo-text">Pet's Heart</p>
      </VRow>
      <img src="@/assets/images/notif.svg" alt="" />
    </VRow>
    <div class="profile">
      <h2>Профиль</h2>
      <div class="profile-photo">
        <img src="@/assets/images/test.svg" alt="Profile Photo" />
      </div>
      <div class="personal-data">
        <h3>Персональные данные</h3>
        <div class="form-field top">
          <label for="last-name">Фамилия</label>
          <input
            type="text"
            id="last-name"
            v-model="lastName"
            placeholder="Неизвестно"
          />
        </div>
        <div class="form-field center">
          <label for="first-name">Имя</label>
          <input
            type="text"
            id="first-name"
            v-model="firstName"
            placeholder="Неизвестно"
            class=""
          />
        </div>
        <div class="form-field bottom">
          <label for="patronymic">Отчество</label>
          <input
            type="text"
            id="patronymic"
            v-model="patronymic"
            placeholder="Неизвестно"
          />
        </div>
        <button @click="saveData">Сохранить данные</button>
      </div>
    </div>
  </VCol>
</template>

<script setup>
import VRow from "@/components/UI/VRow.vue";
import VCol from "@/components/UI/VCol.vue";
</script>

<style scoped>
.header {
  padding: 56px 53px 0px 53px;
}

.logo-text {
  font-size: 30px;
  font-weight: 400;
}

.image-container {
  width: 74px;
  height: 66px;
  margin-right: 12px;
}

.image-logo {
  width: 100%;
}

.profile {
  max-width: 482px;
  margin: 60px auto;
}

.profile-photo {
  text-align: start;
  margin-bottom: 20px;
}

.profile-photo img {
  width: 150px;
  height: 150px;
  border-radius: 50%;
}

.form-field {
  padding: 12px 0px;
}

.form-field.top {
  border-top: 1px solid #d1e1ff;
}

.form-field.center {
  border-top: 1px solid #d1e1ff;
  border-bottom: 1px solid #d1e1ff;
}

.form-field.bottom {
  border-bottom: 1px solid #d1e1ff;
}

label {
  display: block;
  margin-bottom: 5px;
  color: black;
  font-size: 16px;
}

input[type="text"] {
  width: 100%;
  border: none;
}

input[type="text"]:focus {
  outline: none;
}

button {
  padding: 10px 20px;
  background-color: #d1e1ff;
  border: none;
  width: 100%;
  border-radius: 100px;
  margin-top: 24px;
  cursor: pointer;
}
</style>
