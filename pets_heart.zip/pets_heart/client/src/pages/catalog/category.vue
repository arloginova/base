<template>
  <div class="main-layout">
    <VHeader :show-nav="true"></VHeader>
    <VRow class="content">
      <VCol class="content-actions">
        <VCustomButton
          :is-active="selectedForm == 'Основное'"
          button-text="Основное"
          @clicked="changeSelectedForm('Основное')"
        ></VCustomButton>
        <VCustomButton
          :is-active="selectedForm == 'Товары'"
          button-text="Товары"
          @clicked="changeSelectedForm('Товары')"
        ></VCustomButton>
      </VCol>
      <VCompanyForm
        v-if="selectedForm == 'Основное'"
        :user-id="phone"
        :on-submit="handleSubmit"
      ></VCompanyForm>
      <VProductForm
        v-if="selectedForm == 'Товары'"
        :company-id="companyId.value"
        :on-submit="uploadProduct"
        :user-id="phone"
      ></VProductForm>
    </VRow>
    <VFooter></VFooter>
  </div>
</template>

<style scoped>
.main-layout {
  display: flex;
  flex-direction: column;
  min-height: 100vh;
  padding: 48px 80px;
}

.content {
  padding: 73px 0px;
}

.content-actions {
  padding-right: 112px;
}
</style>

<script setup>
import VRow from "@/components/UI/VRow.vue";
import VCol from "@/components/UI/VCol.vue";
import VFooter from "@/components/VFooter.vue";
import VHeader from "@/components/VHeader.vue";
import VCustomButton from "@/components/VCustomButton.vue";
import VCompanyForm from "@/components/VCompanyForm.vue";
import VProductForm from "@/components/VProductForm.vue";
import { ref, computed } from "vue";
import { useRouter } from "vue-router";

const router = useRouter();

const phone = computed(() => {
  return router.currentRoute.value.params.phone || "";
});

const selectedForm = ref("Основное");
const companyId = ref("");

function changeSelectedForm(value) {}

function handleSubmit(value) {
  companyId.value = value;
  selectedForm.value = "Товары";
}

function uploadProduct() {
  router.push(`/profile/${phone.value}`);
}
</script>
