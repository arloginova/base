<template>
  <div class="main-layout">
    <VLoginContainer></VLoginContainer>
  </div>
</template>

<script setup>
import VRow from "@/components/UI/VRow.vue";
import VCol from "@/components/UI/VCol.vue";
import VLoginContainer from "@/components/VLoginContainer.vue";
</script>

<style scoped>
.main-layout {
  display: flex;
  justify-content: center;
  flex-direction: column;
  min-height: 100vh;
  padding: 48px 80px;
}
</style>
