import { Router, DBJson } from '../../core/index.js';

const usersRouter = new Router();


usersRouter.post('/signin', (request, response) => {

    let data = '';

    request
        .on('data', (chunck) => {
            data += chunck;
        })
        .on('end', () => {

            if (data === '') {
                response.writeHead(400, {
                    'Content-type': 'application/json'
                });
                response.end(JSON.stringify({
                    "success": false,
                    "error": "can't valid data",
                }));
                return;
            }

            const user = JSON.parse(data);


            const login =  user.login;

            if (typeof login !== 'string') {
                response.writeHead(400, {
                    'Content-type': 'application/json'
                });
                response.end(JSON.stringify({
                    "success": false,
                    "error": "can't valid data",
                }));
                return;
            }

            const DBUsers = new DBJson('./src/db/users.json');

            const isRegister = DBUsers.findByKey(login);

            console.log(isRegister);

            if (isRegister != undefined || isRegister != null) {
                response.writeHead(200, {
                    'Content-type': 'application/json'
                });
                response.end(JSON.stringify({
                    "success": true,
                    "data": isRegister,
                }));
                return;
            }

            const check = login.includes("@");

            const id = generateRandomNumber();


            if (check) {
                response.writeHead(200, {
                    'Content-type': 'application/json'
                });

                const payLoad = {
                    id: id,
                    method: "email",
                    login: login,
                };

                DBUsers.add(payLoad, login);

                response.end(JSON.stringify({
                    success: true,
                    method: "email",
                    data: payLoad,
                }));

                return;
            }

            response.writeHead(200, {
                'Content-type': 'application/json'
            });

            const payLoad = {
                id: id,
                method: "phone",
                login: login,
            };

            DBUsers.add(payLoad, login);

            response.end(JSON.stringify({
                success: true,
                method: "phone",
                data: payLoad,
            }));


            return;
        });
});


usersRouter.post("/account/delete", (request, response) => {
    let data = '';

    request
        .on('data', (chunck) => {
            data += chunck;
        })
        .on('end', () => {
            if (data === "") {
                response.writeHead(400, {
                    'Content-type': 'application/json'
                });
                response.end(JSON.stringify({
                    "success": false,
                    "error": "can't valid data",
                }));
                return;
            }

            const parsedData = JSON.parse(data);

            const DBProfile = new DBJson('./src/db/profile.json')

            DBProfile.deleteValueFromKey(parsedData.id);

            const DBUsers = new DBJson('./src/db/users.json');

            const find = DBUsers.getValueByParams(parsedData.id, "id");

            if (find == undefined || find == null) {
                response.writeHead(200, {
                    'Content-type': 'application/json'
                });

                response.end(JSON.stringify({
                    "success": true,
                }));
                return;
            }

            DBUsers.deleteValueFromKey(find.login);

            response.writeHead(200, {
                'Content-type': 'application/json'
            });
            response.end(JSON.stringify({
                "success": true,
            }));

            return;
        });
});


usersRouter.get("/account/info", (request, response) => {
    let data = '';

    request
        .on('data', (chunck) => {
            data += chunck;
        })
        .on('end', () => {
            if (data === "") {
                response.writeHead(400, {
                    'Content-type': 'application/json'
                });
                response.end(JSON.stringify({
                    "success": false,
                    "error": "can't valid data",
                }));
                return;
            }

            const parsedData = JSON.parse(data);

            console.log(parsedData);

            const DBProfile = new DBJson('./src/db/profile.json');

            const info = DBProfile.getValueByParams(parsedData.id, "id");

            if (info == undefined || info == null) {
                response.writeHead(200, {
                    'Content-type': 'application/json'
                });

                const responseData = {
                    success: true,
                    isNew: true,
                    data: {
                        firstname: "",
                        lastname: "",
                        surname: "",
                    }
                };

                response.end(JSON.stringify(responseData));

                return;
            }

            console.log(info);

            const responseData = {
                success: true,
                isNew: false,
                data: {
                    firstname: info.info.firstname,
                    lastname: info.info.lastname,
                    surname: info.info.surname,
                }
            }

            response.writeHead(200, {
                'Content-type': 'application/json'
            });
            response.end(JSON.stringify(responseData));
        });
});


usersRouter.post("/account/update", (request, response) => {
    let data = '';

    request
        .on('data', (chunck) => {
            data += chunck;
        })
        .on('end', () => {
            if (data === "") {
                response.writeHead(400, {
                    'Content-type': 'application/json'
                });
                response.end(JSON.stringify({
                    "success": false,
                    "error": "can't valid data",
                }));
                return;
            }

            const parsedData = JSON.parse(data);

            console.log(parsedData);

            const DBProfile = new DBJson('./src/db/profile.json');

            if (typeof parsedData.id !== 'number') {
                response.writeHead(400, {
                    'Content-type': 'application/json'
                });

                response.end(JSON.stringify({
                    success: false,
                    error: "can't valid data"
                }));

                return;
            }

            for (const key in parsedData.info) {
                if (typeof parsedData.info[key] !== 'string') {
                    response.writeHead(400, {
                        'Content-type': 'application/json'
                    });

                    response.end(JSON.stringify({
                        success: false,
                        error: "can't valid data"
                    }));

                    return;
                }

                if (parsedData.info[key] === "") {
                    response.writeHead(400, {
                        'Content-type': 'application/json'
                    });

                    response.end(JSON.stringify({
                        success: false,
                        error: "can't valid data"
                    }));

                    return;
                }
            }

            DBProfile.updateValueByKey(parsedData.id, "info", parsedData);

            response.writeHead(200, {
                'Content-type': 'application/json'
            });
            response.end(JSON.stringify({
                "success": true,
            }));
            return;
        });
});


usersRouter.get("/users/infoAll", (request, response) => {
    let data = '';

    request
        .on('data', (chunck) => {
            data += chunck;
        })
        .on('end', () => {
            const DBProfile = new DBJson('./src/db/users.json');

            const info = DBProfile.getAll();


            response.writeHead(200, {
                'Content-type': 'application/json'
            });
            response.end(JSON.stringify({
                success: true,
                data: info,
            }));
            return;
        });
});


usersRouter.get("/profile/infoAll", (request, response) => {
    let data = '';

    request
        .on('data', (chunck) => {
            data += chunck;
        })
        .on('end', () => {
            const DBProfile = new DBJson('./src/db/profile.json');

            const info = DBProfile.getAll();


            response.writeHead(200, {
                'Content-type': 'application/json'
            });
            response.end(JSON.stringify({
                success: true,
                data: info,
            }));
            return;
        });
});




function generateRandomNumber() {
    return Math.floor(Math.random() * 10000) + 1;
}


export {
    usersRouter
};